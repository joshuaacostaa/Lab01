// supabase.js
import { createClient } from "https://esm.sh/@supabase/supabase-js";

const SUPABASE_URL = "https://bmnawkypxrmnocngvfbg.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJtbmF3a3lweHJtbm9jbmd2ZmJnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ0MzE3MTYsImV4cCI6MjA4MDAwNzcxNn0.hKBJ6coYfofyhemXQYFlTqPRbxTZc0qWYg2NNs-2QlQ";

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// ------------------------------
// FUNCIONES CRUD GENERALES
// ------------------------------

export async function listar(tabla) {
  const { data, error } = await supabase.from(tabla).select("*");

  if (error) {
    console.error(error);
    alert("Error al listar " + tabla);
    return [];
  }
  return data;
}

export async function insertar(tabla, valores) {
  const { error } = await supabase.from(tabla).insert(valores);

  if (error) {
    console.error(error);
    alert("Error al insertar en " + tabla);
  }
}

export async function eliminar(tabla, columnaId, id) {
  const { error } = await supabase.from(tabla).delete().eq(columnaId, id);

  if (error) {
    console.error(error);
    alert("Error al eliminar en " + tabla);
  }
}

export async function actualizar(tabla, columnaId, id, valores) {
  const { error } = await supabase.from(tabla).update(valores).eq(columnaId, id);

  if (error) {
    console.error(error);
    alert("Error al actualizar en " + tabla);
  }
}

// ------------------------------
// AUTENTICACIÓN
// ------------------------------
export async function login(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    alert("Error al iniciar sesión");
    return null;
  }

  return data.user;
}

export async function logout() {
  const { error } = await supabase.auth.signOut();
  return !error;
}

export async function getUsuario() {
  const { data } = await supabase.auth.getUser();
  return data.user;
}
