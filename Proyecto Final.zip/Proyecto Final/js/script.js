import { getUsuario } from "./supabase.js";

/* ============================================
   PROTEGER PÁGINA
============================================ */
export async function protegerPagina() {
  const user = await getUsuario();
  if (!user) {
    alert("Debe iniciar sesión primero.");
    window.location.href = "registro.html";
  }
}

/* ============================================
   CONFIGURAR NAVBAR
============================================ */
export function configurarNavbar() {
  const navbarRight = document.getElementById("navbar-buttons");

  if (!navbarRight) {
    console.error("No se encontró el contenedor con id='navbar-buttons'");
    return;
  }

  // Limpiar por si acaso para no duplicar botones
  navbarRight.innerHTML = "";

  const esMenu = window.location.pathname.includes("index.html");

  // 1. Botón REGRESAR (Solo si no estamos en el menú)
  if (!esMenu) {
    const btnMenu = document.createElement("button");
    // Usamos nuestra clase personalizada de CSS
    btnMenu.className = "btn btn-regresar-custom me-2";
    btnMenu.textContent = "Regresar al Menú";
    btnMenu.onclick = () => {
      window.location.href = "index.html";
    };
    navbarRight.appendChild(btnMenu);
  }

  // 2. Botón CERRAR SESIÓN
  const btnCerrar = document.createElement("button");
  // Usamos nuestra clase personalizada de CSS
  btnCerrar.className = "btn btn-salir-custom";
  btnCerrar.textContent = "Cerrar sesión";
  btnCerrar.onclick = () => {
    if(confirm("¿Seguro que desea cerrar sesión?")) {
      localStorage.removeItem("usuarioLogueado");
      window.location.href = "registro.html";
    }
  };
  navbarRight.appendChild(btnCerrar);
}