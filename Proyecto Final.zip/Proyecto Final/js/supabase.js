import { createClient } from "https://esm.sh/@supabase/supabase-js";

// =======================================
// CONFIGURACIÓN DE SUPABASE
// =======================================

const SUPABASE_URL = "https://bmnawkypxrmnocngvfbg.supabase.co";
const SUPABASE_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJtbmF3a3lweHJtbm9jbmd2ZmJnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ0MzE3MTYsImV4cCI6MjA4MDAwNzcxNn0.hKBJ6coYfofyhemXQYFlTqPRbxTZc0qWYg2NNs-2QlQ";

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// =======================================
// OBTENER USUARIO PARA VALIDAR SESIÓN
// =======================================

export async function getUsuario() {
  const email = localStorage.getItem("usuarioLogueado");
  if (!email) return null;

  // Si quisieras validar contra una tabla "usuarios", aquí se haría.
  return { email };
}

// =======================================
// CRUD GENERALES
// =======================================

export async function listar(tabla) {
  try {
    const { data, error } = await supabase.from(tabla).select("*");

    if (error) {
      console.error("Error al listar:", error);
      return [];
    }

    return data ?? [];
  } catch (err) {
    console.error("Error inesperado:", err);
    return [];
  }
}

export async function insertar(tabla, valores) {
  try {
    const { error } = await supabase.from(tabla).insert(valores);

    if (error) {
      console.error("Error al insertar:", error);
      alert("No se pudo insertar el registro.");
    }
  } catch (err) {
    console.error("Error inesperado:", err);
  }
}

export async function eliminar(tabla, columnaId, id) {
  try {
    const { error } = await supabase.from(tabla).delete().eq(columnaId, id);

    if (error) {
      console.error("Error al eliminar:", error);
      alert("No se pudo eliminar el registro.");
    }
  } catch (err) {
    console.error("Error inesperado:", err);
  }
}

export async function actualizar(tabla, columnaId, id, valores) {
  try {
    const { error } = await supabase.from(tabla).update(valores).eq(columnaId, id);

    if (error) {
      console.error("Error al actualizar:", error);
      alert("No se pudo actualizar el registro.");
    }
  } catch (err) {
    console.error("Error inesperado:", err);
  }
}
